BITS 16
%INCLUDE "mikedev.inc"
ORG 32768

start:
	call os_clear_screen
	call draw_test
	call os_print_newline
	ret

draw_test:
	mov ah, 0x09
	mov al, 0x03
	mov bx, 0x0004
	int 0x10
	call draw_char
	ret
draw_char:
	pusha
	mov si, char_test
	call os_print_string
	popa
	ret

char_test:
	db " ",0x00

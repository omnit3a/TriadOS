BITS 16
%INCLUDE "mikedev.inc"
ORG 32768

start:
	mov dl, 0
	mov si, 40
	mov di, 23
	call os_clear_screen
	mov bl, 0x00
	mov dh, 0x00
	call os_draw_block
	mov bl, 0x11
	mov dh, 0x01
	call os_draw_block
	mov bl, 0x22
	mov dh, 0x02
	call os_draw_block
	mov bl, 0x33
	mov dh, 0x03
	call os_draw_block
	mov bl, 0x44
        mov dh, 0x04
        call os_draw_block
	mov bl, 0x55
        mov dh, 0x05
        call os_draw_block
	mov bl, 0x66
        mov dh, 0x06
        call os_draw_block
	mov bl, 0x77
        mov dh, 0x07
        call os_draw_block
	mov bl, 0x88
        mov dh, 0x08
        call os_draw_block
	mov bl, 0x99
        mov dh, 0x09
        call os_draw_block
	mov bl, 0xAA
        mov dh, 0x0A
        call os_draw_block
	mov bl, 0xBB
        mov dh, 0x0B
        call os_draw_block
	mov bl, 0xCC
        mov dh, 0x0C
        call os_draw_block
	mov bl, 0xDD
        mov dh, 0x0D
        call os_draw_block
	mov bl, 0xEE
        mov dh, 0x0E
        call os_draw_block
	mov bl, 0xF0
        mov dh, 0x0F
        call os_draw_block

	mov si, exit_msg
	call os_print_string

	call os_wait_for_key
	call os_clear_screen
	ret
	
exit_msg:
	db "Press any key to exit...",0x00
